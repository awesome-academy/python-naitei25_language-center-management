# custom_admin/urls.py
from django.urls import path

urlpatterns = [] # Đây là một danh sách hợp lệ, ngay cả khi rỗng.
