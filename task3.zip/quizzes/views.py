# quizzes/views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render

from .forms import QuizForm
from .models import Choice, Quiz


@login_required
def quiz_detail(request, lesson_id: int):
    """
    Hiển thị form quiz (GET) và xử lý kết quả (POST) với UI mới.
    - Prefetch để giảm N+1
    - Chống chia cho 0 khi chưa có câu hỏi
    - Trả 'review' cho trang kết quả
    """
    quiz = get_object_or_404(
        Quiz.objects.select_related("lesson").prefetch_related("questions__choices"),
        lesson_id=lesson_id,
    )
    questions = list(quiz.questions.all())

    if request.method == "POST":
        form = QuizForm(request.POST, quiz=quiz)
        if form.is_valid():
            total_q = len(questions)
            correct = 0
            review = []

            for q in questions:
                field = f"question_{q.pk}"
                sel_raw = form.cleaned_data.get(field)
                sel_id = int(sel_raw) if sel_raw is not None else None

                # tìm lựa chọn người dùng & đáp án đúng
                user_choice = None
                correct_choice = None
                for ch in q.choices.all():
                    if sel_id is not None and ch.pk == sel_id:
                        user_choice = ch
                    if ch.is_correct:
                        correct_choice = ch

                is_correct = bool(user_choice and user_choice.is_correct)
                if is_correct:
                    correct += 1

                review.append({
                    "question": q.text,
                    "user_choice": user_choice.text if user_choice else "—",
                    "correct_choice": correct_choice.text if correct_choice else "—",
                    "is_correct": is_correct,
                })

            score = round((correct / total_q) * 100, 2) if total_q else 0.0
            passed = score >= quiz.pass_rate if total_q else False

            return render(
                request,
                "quizzes/result.html",   # UI template mới
                {
                    "quiz": quiz,
                    "score": score,
                    "passed": passed,
                    "review": review,
                },
            )
    else:
        form = QuizForm(quiz=quiz)

    # GET
    return render(
        request,
        "quizzes/detail.html",        # UI template mới
        {
            "quiz": quiz,
            "form": form,
            "questions": questions,    # nếu template muốn duyệt trực tiếp
        },
    )
